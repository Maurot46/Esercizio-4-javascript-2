var menu = document.getElementById('bottoneMenu');

menu.addEventListener('click', function() {
    document.getElementById('elementiMenu').classList.toggle('show');
})
menu.addEventListener('focusin', function() {
    document.getElementById('bottoneMenu').style.backgroundColor = 'cyan';
})
menu.addEventListener('focusout', function() {
    document.getElementById('bottoneMenu').style.backgroundColor = 'rgb(0, 98, 255)';
})
document.getElementById('grande').addEventListener('click', function(){
    document.getElementById('titolo').classList.toggle('diventaGrande');
})
document.getElementById('colore').addEventListener('click', function(){
    document.getElementById('titolo').style.color = 'red';
})
document.getElementById('maiuscolo').addEventListener('click', function(){
    document.getElementById('titolo').classList.add('uppercase');
    document.getElementById('titolo').classList.replace('lowercase','uppercase');
})
document.getElementById('minuscolo').addEventListener('click', function(){
    document.getElementById('titolo').classList.add('lowercase');
    document.getElementById('titolo').classList.replace('uppercase','lowercase');
})
document.getElementById('nascondi').addEventListener('click', function(){
    document.getElementById('titolo').classList.add('nascondi');
})
document.getElementById('mostrare').addEventListener('click', function(){
    document.getElementById('titolo').classList.replace('nascondi','visible');
})
const li = document.querySelectorAll('.elementiLista');
let flag = true;

for (let i = 0; i < li.length; i++) {
    li[i].addEventListener('click', () => {
        if (flag) {
            li[i].style.textDecoration = 'line-through';
            li[i].style.color = 'gray';
            flag = false;
        } else {
            li[i].style.textDecoration = 'none';
            li[i].style.color = 'black';
            flag = true;
        }
    })
}